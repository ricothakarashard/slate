---
title: "Dive-In and Publish Already!"
lesson: 3
approx_time: 30 mins
---

Jekyll converts Markdown documents to HTML by default. Don't know what's Markdown?
Read this [documentation](https://daringfireball.net/projects/markdown/)
While you're at it, might as well learn about [Kramdown](https://kramdown.gettalong.org/)
